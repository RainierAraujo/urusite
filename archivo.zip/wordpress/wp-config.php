<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'uruarauj_wordpressDB');

/** MySQL database username */
define('DB_USER', 'uruarauj_wpDB');

/** MySQL database password */
define('DB_PASSWORD', '20863638');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ')b4V~AJ w$EzTMK0Q)<>JVQ^#Y[J7J514L~m(do@;H-?_QO>0Hl{2oaBz@X8`YL_');
define('SECURE_AUTH_KEY',  '~yWSgHs%<]1Gl]-.w~_Ea[n/(!|A`YoHyZr(h[]HavWZwBbQ>odhQDmaLl,e[p$&');
define('LOGGED_IN_KEY',    'Y^>y8.mDx$TPoA@2VE}~mUK/~FeVNwf[LQ#>04`40}maDG20K_Roei#i<>o)/AA7');
define('NONCE_KEY',        'pda$u0EG3LchmCc+gS[6X#&=l#bLnW7G&jFjyP}YQ/q>|<_sTN#wDRy1LH3m%U&[');
define('AUTH_SALT',        '}VW<C?}-TynuWCon]h`3.M*M,x%Gsh?_G,EE<pvGtVfh(IT[9ol^p:re|qofYG26');
define('SECURE_AUTH_SALT', 'WuQEi9FXCdNcGY0@x%uK=R/J1)#f@Lw$R{&gfxA#4xQFogoC5R`m=XmC*rkhoAgo');
define('LOGGED_IN_SALT',   '&bL]I5Q=!|#+^+<=rGH?1C>(!EzE}%(<wdn26Gus}T,`B:+n@+UNn $Gw{_,@Kg-');
define('NONCE_SALT',       '{(jx7`]Ut)i:Fg>Ur$|7HL*2`7pA<|]}:U$.;DjsgSkWMn0*OC*9t{Iw$A %|-c:');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
