var main = function() {
   $('.list-element').click(function(){
       var currentSection = $('.list-element-selected');
       var clickedSection = $(this);
       currentSection.removeClass('list-element-selected').addClass('list-element');
       clickedSection.addClass('list-element-selected');
       switch(clickedSection.index('li')){
           case 0:
               $('html, body').animate({
        scrollTop: $('.aboutme').offset().top
       }, 500);
               break;
           case 1:
                $('html, body').animate({
        scrollTop: $('.projects').offset().top
       }, 500);
               break;
           case 2:
                $('html, body').animate({
        scrollTop: $('.contact').offset().top
       }, 500);
               break;
       }
   });
    
     $('.arrow-next').click(function() {
    var currentSlide = $('.active-slide');
    var nextSlide = currentSlide.next();

    var currentDot = $('.active-dot');
    var nextDot = currentDot.next();

    if(nextSlide.length === 0) {
      nextSlide = $('.slide').first();
      nextDot = $('.dot').first();
    }
    
    currentSlide.fadeOut(600).removeClass('active-slide');
    nextSlide.fadeIn(600).addClass('active-slide');
    currentDot.removeClass('active-dot');
    nextDot.addClass('active-dot');
  });

   $('.arrow-prev').click(function() {
    var currentSlide = $('.active-slide');
    var prevSlide = currentSlide.prev();

    var currentDot = $('.active-dot');
    var prevDot = currentDot.prev();

    if(prevSlide.length === 0) {
      prevSlide = $('.slide').last();
      prevDot = $('.dot').last();
    }
    
    currentSlide.fadeOut(600).removeClass('active-slide');
    prevSlide.fadeIn(600).addClass('active-slide');

    currentDot.removeClass('active-dot');
    prevDot.addClass('active-dot');
  });
    
    $('.facebook').click(function(){
        window.open('https://www.facebook.com/profile.php?id=1320151979','_blank');
    });
    $('.linkedin').click(function(){
       window.open('https://ve.linkedin.com/in/rainier-araujo-36b86a53','_blank'); 
    });
    $('.gmail').click(function(){
       window.open('mailto:username@example.com','_blank'); 
    });
    $('.to-top').click(function(){
        $('html, body').animate({
        scrollTop: $('.header').offset().top
       }, 500);
    }); 
}
$(document).ready(main);