 
<?php
$con=mysqli_connect("localhost","uruarauj_darkbub","20863638a","uruarauj_juegos");
?> 