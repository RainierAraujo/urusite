 
<?php
$con=mysqli_connect("localhost","uruarauj_rainier","20863638","uruarauj_clases");
?> 