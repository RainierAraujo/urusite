var codropsEvents = {
'01-20-2014' : '<span>prueba ddd</span><br>',
'01-30-2014' : '<span>prueba ddd</span><br>',
'01-18-2014' : '<span>prueba ddd</span><br>',
}