angular.module('Portfolio').config(function($routeProvider){
    $routeProvider.when('/about',{
       templateUrl: '../views/about.html' 
    }).when('/',{
       templateUrl: '../culo.html' 
    });
});